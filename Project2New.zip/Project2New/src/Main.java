public class Main {


    public static void main(String[] args) {
        GameField game = new GameField();
    }
}